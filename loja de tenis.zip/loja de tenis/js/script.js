document.addEventListener("DOMContentLoaded", () => {
    // Atualizar Badge do Carrinho se existir
    atualizarContadorCarrinho();

    // Validação básica do formulário de contato no Front-end
    const formContato = document.getElementById("formContato");
    if (formContato) {
        formContato.addEventListener("submit", (e) => {
            const nome = document.getElementById("nome").value.trim();
            const email = document.getElementById("email").value.trim();
            if (!nome || !email) {
                e.preventDefault();
                alert("Por favor, preencha os campos obrigatórios!");
            }
        });
    }
});

// Adicionar produto ao LocalStorage (Carrinho)
function adicionarAoCarrinho(nome, preco) {
    let carrinho = JSON.parse(localStorage.getItem("carrinho")) || [];
    carrinho.push({ nome, preco });
    localStorage.setItem("carrinho", JSON.stringify(carrinho));
    alert(`${nome} foi adicionado ao seu carrinho!`);
    atualizarContadorCarrinho();
}

function atualizarContadorCarrinho() {
    let carrinho = JSON.parse(localStorage.getItem("carrinho")) || [];
    const badge = document.getElementById("cart-count");
    if (badge) {
        badge.textContent = carrinho.length;
    }
}

// Carregar itens na página carrinho.html
function carregarCarrinho() {
    const lista = document.getElementById("lista-carrinho");
    const totalElemento = document.getElementById("total-carrinho");
    if (!lista) return;

    let carrinho = JSON.parse(localStorage.getItem("carrinho")) || [];
    lista.innerHTML = "";
    let total = 0;

    if (carrinho.length === 0) {
        lista.innerHTML = "<tr><td colspan='3'>Seu carrinho está vazio.</td></tr>";
        totalElemento.textContent = "0.00";
        return;
    }

    carrinho.forEach((item, index) => {
        total += parseFloat(item.preco);
        lista.innerHTML += `
            <tr>
                <td>${item.nome}</td>
                <td>R$ ${parseFloat(item.preco).toFixed(2)}</td>
                <td><button onclick="removerDoCarrinho(${index})" class="btn btn-danger">Remover</button></td>
            </tr>
        `;
    });

    totalElemento.textContent = total.toFixed(2);
}

function removerDoCarrinho(index) {
    let carrinho = JSON.parse(localStorage.getItem("carrinho")) || [];
    carrinho.splice(index, 1);
    localStorage.setItem("carrinho", JSON.stringify(carrinho));
    carregarCarrinho();
    atualizarContadorCarrinho();
}

function limparCarrinho() {
    localStorage.removeItem("carrinho");
    carregarCarrinho();
    atualizarContadorCarrinho();
}